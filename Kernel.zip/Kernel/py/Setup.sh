#!/usr/bin/env bash
echo -e "Setup Started Please Wait..."
echo -e ">>>>>>>>> @PlusTM <<<<<<<<<<"
sleep 2
sudo apt-get install python-pip
pip install pyTelegramBotAPI
git clone https://github.com/eternnoir/pyTelegramBotAPI.git
cd pyTelegramBotAPI
python setup.py install
cd ..
sudo apt-get install python-setuptools
sudo apt-get install python-pip
sudo apt-get install python-redis
sudo pip install pyTelegramBotAPI
apt-get install python setup-tools
sudo pip install pyTelegramBotAPI —upgrade
sudo apt-get update
sudo apt-get install python2.7
chmod +x Anti.sh
echo -e "Thanks for Used AntiPlus"
sleep 2
echo -e "Please Set TOKEN and Sudo ID To AntiPlus.py"
sleep 3
echo -e "Type screen ./Anti.sh"
