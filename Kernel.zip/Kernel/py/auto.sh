while true ; do
python Helper.py
curl "https://api.telegram.org/bot5034071891:AAEshtJVw83BXEhhwdoL6GpVc-fFGk3GeVE/sendMessage" -F "chat_id=-1001635694018" -F "text= > ReacTancE Helper RoBot Crashed ! Lunching Again Robot XD"
sleep 5
done
