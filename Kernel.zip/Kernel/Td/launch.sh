#!/bin/bash
curl "https://api.telegram.org/bot1989457547:AAGSRqgDDQrPqW0NMR642p60YqYx6ZzDMWE/sendMessage" -F "chat_id=-1001635694018" -F "text= > iRKernel Robot Has Been Running ...!"
./tg | grep -v "{"

