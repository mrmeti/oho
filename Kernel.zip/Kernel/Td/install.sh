#!/bin/bash

THIS_DIR=$(cd $(dirname $0); pwd)
cd $THIS_DIR

install() {
	    cd Kernel && cd Td
	wget http://luarocks.org/releases/luarocks-2.2.2.tar.gz;tar zxpf luarocks-2.2.2.tar.gz;cd luarocks-2.2.2 && ./configure; sudo make bootstrap;sudo luarocks install luasocket;sudo luarocks install luasec;sudo luarocks install redis-lua;sudo luarocks install lua-term;sudo luarocks install serpent;sudo luarocks install dkjson;sudo luarocks install lanes;sudo luarocks install Lua-cURL;cd ..
		sudo add-apt-repository -y ppa:ubuntu-toolchain-r/test
		sudo apt-get install g++-4.7 -y c++-4.7 -y
		sudo apt-get update
		sudo apt-get upgrade
		sudo apt-get install libreadline-dev -y libconfig-dev -y libconfig++-dev -y libssl-dev -y lua5.2 -y liblua5.2-dev -y lua-socket -y lua-sec -y lua-expat -y libevent-dev -y make unzip git redis-server autoconf g++ -y libjansson-dev -y libpython-dev -y expat libexpat1-dev -y
		sudo apt-get install screen -y
		sudo apt-get install tmux -y
		sudo apt-get install libstdc++6 -y
		sudo apt-get install lua-lgi -y
		sudo apt-get install libnotify-dev -y
		wget https://valtman.name/files/telegram-bot-180116-nightly-linux
		mv telegram-bot-180116-nightly-linux tg
		chmod +x tg
		chmod +x bot.lua
		chmod +x auto.sh
}

red() {
  printf '\e[1;31m%s\n\e[0;39;49m' "$@"
}
green() {
  printf '\e[1;32m%s\n\e[0;39;49m' "$@"
}
white() {
  printf '\e[1;37m%s\n\e[0;39;49m' "$@"
}
update() {
	git pull
}
deltgbot() {
 rm -rf $HOME/.telegram-bot
}
 config() {
mkdir $HOME/.telegram-bot; cat <<EOF > $HOME/.telegram-bot/config
default_profile = "cli";
cli = {
lua_script = "$HOME/Kernel/Td/bot.lua";
};
EOF
printf "\nConfig Has Been Saved.\n"
}
kernel() {
./tg | grep -v "{"
}

cli() {
./tg -p cli --login --phone=${1}
} 

api() {
./tg -p cli --login --bot=${1}
}

case $1 in
config)
printf "Please wait...\n"
config ${2}
exit ;;

logcli)
echo "Please Insert Your Phone Number..."
read phone_number
cli ${phone_number}
echo 'Your Cli Bot Loged In Successfully.'
exit;;

logapi)
echo "Please Insert Your Bot Token..."
read Bot_Token
api ${Bot_Token}
echo 'Your Api Bot Loged In Successfully.'
exit;;

install)
install
exit;;

run)
printf "New Kernel is Launching...\n"
kernel
exit;;

reset)
printf "Please wait for delete telegram-bot...\n"
deltgbot
sleep 1
echo '.telegram-bot Deleted Successfully.'
exit;;

esac

exit 0