while true ; do
./launch.sh
curl "https://api.telegram.org/bot568694935:AAFsNdTv123xdcv1LIYF7xQCfv9xpcaT8q0/sendMessage" -F "chat_id=-1001243033388" -F "text= > iRKernel RoBot Crashed ! Lunching Again Robot XD"
sleep 15
done